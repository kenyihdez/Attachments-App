﻿namespace WFA_Attachments
{
    partial class frmAttachments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdRetrieve = new System.Windows.Forms.Button();
            this.cmdCancel = new System.Windows.Forms.Button();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.txtDirectory = new System.Windows.Forms.TextBox();
            this.cmdSearch = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.sqlConnect = new System.Data.SqlClient.SqlConnection();
            this.sqlMainConnect = new System.Data.SqlClient.SqlConnection();
            this.lblProgress = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmdRetrieve
            // 
            this.cmdRetrieve.Location = new System.Drawing.Point(324, 99);
            this.cmdRetrieve.Name = "cmdRetrieve";
            this.cmdRetrieve.Size = new System.Drawing.Size(121, 42);
            this.cmdRetrieve.TabIndex = 0;
            this.cmdRetrieve.Text = "&Retrieve";
            this.cmdRetrieve.UseVisualStyleBackColor = true;
            this.cmdRetrieve.Click += new System.EventHandler(this.cmdRetrieve_Click);
            // 
            // cmdCancel
            // 
            this.cmdCancel.Location = new System.Drawing.Point(197, 99);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(121, 42);
            this.cmdCancel.TabIndex = 1;
            this.cmdCancel.Text = "Ca&ncel";
            this.cmdCancel.UseVisualStyleBackColor = true;
            this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
            // 
            // txtDirectory
            // 
            this.txtDirectory.Location = new System.Drawing.Point(12, 48);
            this.txtDirectory.Name = "txtDirectory";
            this.txtDirectory.ReadOnly = true;
            this.txtDirectory.Size = new System.Drawing.Size(433, 26);
            this.txtDirectory.TabIndex = 2;
            // 
            // cmdSearch
            // 
            this.cmdSearch.Location = new System.Drawing.Point(451, 47);
            this.cmdSearch.Name = "cmdSearch";
            this.cmdSearch.Size = new System.Drawing.Size(45, 32);
            this.cmdSearch.TabIndex = 3;
            this.cmdSearch.Text = "...";
            this.cmdSearch.UseVisualStyleBackColor = true;
            this.cmdSearch.Click += new System.EventHandler(this.cmdSearch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(305, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Directory where to store the retrieved files.";
            // 
            // sqlConnect
            // 
            this.sqlConnect.ConnectionString = "Data Source=PKP-PAT02;Initial Catalog=PatriotV2_PKP;Persist Security Info=True;Us" +
    "er ID=sa;Password=$qL@pkP1!";
            this.sqlConnect.FireInfoMessageEventOnUserErrors = false;
            // 
            // sqlMainConnect
            // 
            this.sqlMainConnect.ConnectionString = "Data Source=PKP-PAT02;Initial Catalog=PatriotV2_PKP;Persist Security Info=True;Us" +
    "er ID=sa;Password=$qL@pkP1!";
            this.sqlMainConnect.FireInfoMessageEventOnUserErrors = false;
            // 
            // lblProgress
            // 
            this.lblProgress.AutoSize = true;
            this.lblProgress.Location = new System.Drawing.Point(12, 157);
            this.lblProgress.Name = "lblProgress";
            this.lblProgress.Size = new System.Drawing.Size(0, 20);
            this.lblProgress.TabIndex = 5;
            // 
            // frmAttachments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(527, 186);
            this.Controls.Add(this.lblProgress);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmdSearch);
            this.Controls.Add(this.txtDirectory);
            this.Controls.Add(this.cmdCancel);
            this.Controls.Add(this.cmdRetrieve);
            this.Name = "frmAttachments";
            this.Text = "KAT Attachments Retrieval Tool";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdRetrieve;
        private System.Windows.Forms.Button cmdCancel;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.TextBox txtDirectory;
        private System.Windows.Forms.Button cmdSearch;
        private System.Windows.Forms.Label label1;
        private System.Data.SqlClient.SqlConnection sqlConnect;
        private System.Data.SqlClient.SqlConnection sqlMainConnect;
        private System.Windows.Forms.Label lblProgress;
    }
}

