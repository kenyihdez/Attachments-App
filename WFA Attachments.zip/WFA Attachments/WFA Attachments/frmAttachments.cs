﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace WFA_Attachments
{
    public partial class frmAttachments : Form
    {
        public frmAttachments()
        {
            InitializeComponent();
        }

        private void cmdSearch_Click(object sender, EventArgs e)
        {
            // Opens a Directory Dialog box to browse where to put the files
            DialogResult result = folderBrowserDialog.ShowDialog();
            if (result == DialogResult.OK) {
                this.txtDirectory.Text = folderBrowserDialog.SelectedPath;
            }
        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdRetrieve_Click(object sender, EventArgs e)
        {
            //SELECT JournalAttachmentID, AttachmentFileName, Attachment FROM tblJournalAttachments WHERE JournalAttachmentID = (44848, 75426) ORDER BY JournalAttachmentID

            string sAttachSQL = "SELECT Attachment FROM tblJournalAttachments WHERE JournalAttachmentID = @ID";
            // This is Theta string sMainSQL = "SELECT JournalAttachmentID, AttachmentFileName FROM tblJournalAttachments WHERE AND JournalAttachmentID > 137115 ORDER BY JournalAttachmentID";
            // This is for PhiPsi
            string sMainSQL = "SELECT JournalAttachmentID, AttachmentFileName FROM [PatriotV2_PKP].[dbo].[tblJournalAttachments] JOIN tblJournals ON tblJournals.JournalID = tblJournalAttachments.JournalID JOIN tlkJournalTypeCodes ON tlkJournalTypeCodes.JournalTypeCode = tblJournals.JournalTypeCode AND tlkJournalTypeCodes.JournalType = 'Agreement of Responsibility' WHERE JournalAttachmentID > 14866 ORDER BY JournalAttachmentID";

            if (this.txtDirectory.Text != "")
            {
                try {
                    // First create command text to retrieve record
                    SqlCommand cmdMaster = new SqlCommand(sMainSQL, sqlMainConnect);
                    sqlMainConnect.Open();
                    SqlDataReader reader = cmdMaster.ExecuteReader();

                    while (reader.Read()) {
                        lblProgress.Text = reader.GetValue(0).ToString();
                        SqlCommand cmdDetail = new SqlCommand(sAttachSQL, sqlConnect);
                        cmdDetail.Parameters.Add("@ID", SqlDbType.Int, 4); // Create parameter for the query
                        cmdDetail.Parameters["@ID"].Value = reader.GetValue(0); // Provide value to the parameter
                        // Open database connection and execute “ExecuteScalar” because we want only “IMAGE” column data back
                        sqlConnect.Open();
                        byte[] barrImg = (byte[])cmdDetail.ExecuteScalar(); // As the execute scalar returns data of “Object” data type, we cast it to byte array
                        string strfn = txtDirectory.Text + "\\" + reader.GetValue(0) + "-" + reader.GetValue(1);
                        // Prints the current file
                        lblProgress.Text = reader.GetValue(0) + "-" + reader.GetValue(1);
                        this.Refresh();
                        // Save this data to a directory file.
                        FileStream fs = new FileStream(strfn, FileMode.CreateNew, FileAccess.Write);
                        fs.Write(barrImg, 0, barrImg.Length);
                        fs.Flush();
                        fs.Close();
                        sqlConnect.Close();
                    }
                }
                catch (Exception ex) {
                    MessageBox.Show(ex.Message, "Error on excecution", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally {
                    this.sqlConnect.Close();
                    this.sqlMainConnect.Close();
                }
            }
        }
    }
}
